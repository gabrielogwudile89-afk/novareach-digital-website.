export default async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Use POST for chat messages." }), {
      status: 405,
      headers: { "Content-Type": "application/json", "Allow": "POST" }
    });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return Response.json({ error: "The AI assistant is not configured yet. Please contact the website owner." }, { status: 503 });
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Please send a valid message." }, { status: 400 });
  }

  const messages = Array.isArray(body.messages) ? body.messages.slice(-10) : [];
  const cleanMessages = messages
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, 1500) }));

  if (!cleanMessages.length || cleanMessages[cleanMessages.length - 1].role !== "user") {
    return Response.json({ error: "Please enter a message first." }, { status: 400 });
  }

  const instructions = `You are NovaReach AI, the friendly digital assistant for NovaReach Digital.
Help visitors understand digital services, website design, social media support, pricing enquiries, and how to contact the business.
Be clear, professional, welcoming, and concise.
Never invent service availability, prices, guarantees, customer testimonials, contact details, or business policies.
If a visitor asks for pricing, explain that exact pricing depends on their needs and invite them to contact the NovaReach team for a quote.
If a visitor wants to hire NovaReach or leave an enquiry, ask only for the details needed to follow up, such as their name, preferred contact method, and a short description of the project. Tell them that chat messages are not automatically sent to the business unless a contact form or messaging integration has been configured.
Do not ask for passwords, payment card details, bank PINs, or one-time codes.
If you do not know an answer, say so and suggest contacting the team.`;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-mini",
        instructions,
        input: cleanMessages,
        max_output_tokens: 450
      })
    });

    const data = await response.json();
    if (!response.ok) {
      console.error("AI provider error:", data?.error?.message || response.status);
      return Response.json({ error: "The assistant is temporarily unavailable. Please try again later." }, { status: 502 });
    }

    const reply = data.output_text;
    if (!reply) {
      return Response.json({ error: "I couldn't prepare a reply. Please try again." }, { status: 502 });
    }
    return Response.json({ reply });
  } catch (error) {
    console.error("Chat function error:", error);
    return Response.json({ error: "Connection problem. Please try again." }, { status: 500 });
  }
};
