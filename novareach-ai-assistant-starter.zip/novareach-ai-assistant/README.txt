# NovaReach Digital AI Assistant

## Files
- `netlify.toml`: tells Netlify where the static site and function live.
- `netlify/functions/chat.mjs`: securely calls the OpenAI Responses API.
- `widget-snippet.html`: chat UI to add to your existing homepage.

## Before publishing
1. Keep your existing website design and copy `widget-snippet.html` into your homepage immediately before `</body>`.
2. Ensure the homepage is named `index.html` and is in the repository root. If your site uses a different publish folder, adjust `netlify.toml` accordingly.
3. Add `netlify.toml` and the `netlify/functions/chat.mjs` file to your GitHub repository, preserving the folders exactly.
4. In Netlify, open your site > Project configuration > Environment variables. Add `OPENAI_API_KEY` with your own API key. Keep it secret; never place it in HTML or GitHub. Ensure it is available to Functions.
5. Trigger a new production deploy.
6. Test the live site and send a message in the chat.

## Notes
- AI API usage may cost money and is subject to provider limits.
- This starter does not send leads to email or WhatsApp. Chat messages are not automatically delivered to the business. Add a verified contact form or messaging integration separately if you want lead delivery.
- Update the assistant instructions in `chat.mjs` with confirmed service details and approved prices; do not invent prices.
- If your current project publishes a subfolder, set `publish` in `netlify.toml` to that folder and ensure the `netlify` functions directory is deployed.
